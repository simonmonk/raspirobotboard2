raspirobotboard 2
=================

Source for the RaspiRobotBoard Python library.

For full instructions for installation and use, see:

https://github.com/simonmonk/rrb2/wiki

for Version 1 (through hole kit) of the RaspiRobotBoard, see: https://github.com/simonmonk/raspirobotboard/wiki