from distutils.core import setup
setup(name='rrb2', version='1.1', py_modules=['rrb2'])
